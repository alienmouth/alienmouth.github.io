 ---
layout: default
title: december 2015
---
<div align="center">
	<iframe src="https://player.vimeo.com/video/147653721" width="500" height="281" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
    <p><h1>december 2015</h1></p>
</div>
<div align="left">
    {% for post in site.categories.december2015 %}
    <div class="items-wrapper">
        <div class="item">
            <p><a href="{{ site.url }}{{ post.url }}">{{ post.title }} by {{ post.author }}</a>
            <br />
            <br />
        </div>
    </div>
        
{% endfor %}
</div>

<br><br>
<p align="center"><a href="/december2015/people.html">read everyone's bio here</a></p>
<br>

<div align="center">
    <p><h1>previous editions</h1></p>
    {<a href="../july2015/">july 2015</a> / <a href="../fall2015/">fall quarterly 2015</a> / <a href="../september2015/">september 2015</a> <br> <a href="../october2015/">october 2015</a> / <a href="../november2015/">november 2015</a> / <a href="../winter2016/">winter quarterly 2016</a> <br> <a href="../february2016 /">february 2016</a>}
</div>

<br><br>